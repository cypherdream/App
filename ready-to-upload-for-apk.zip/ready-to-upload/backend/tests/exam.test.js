// Requires the generated server.js as-is (it already exports `app`
// and only calls .listen() when run directly — see server.js).
const request = require('supertest');
const app = require('../server');

describe('Exam API', () => {
  let createdId;

  it('rejects creation with missing required fields', async () => {
    const res = await request(app).post('/api/exams').send({});
    expect(res.status).toBe(400);
  });

  it('creates a Exam', async () => {
    const res = await request(app).post('/api/exams').send({ subject: 'Test Value', date: '2026-01-01' });
    expect(res.status).toBe(201);
    expect(res.body.id).toBeDefined();
    createdId = res.body.id;
  });

  it('lists Exams including the one just created', async () => {
    const res = await request(app).get('/api/exams');
    expect(res.status).toBe(200);
    expect(res.body.some((item) => item.id === createdId)).toBe(true);
  });

  it('gets a single Exam by id', async () => {
    const res = await request(app).get(`/api/exams/${createdId}`);
    expect(res.status).toBe(200);
    expect(res.body.id).toBe(createdId);
  });

  it('returns 404 for a nonexistent Exam', async () => {
    const res = await request(app).get('/api/exams/999999999');
    expect(res.status).toBe(404);
  });

  it('deletes the Exam', async () => {
    const res = await request(app).delete(`/api/exams/${createdId}`);
    expect(res.status).toBe(204);
  });
});
