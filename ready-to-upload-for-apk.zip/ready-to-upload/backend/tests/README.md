# Generated tests

Real integration tests (supertest), one file per entity, covering:
create, list, get-by-id, 404-on-missing, delete, and validation
rejection. Run against a real test database — set DATABASE_URL to a
throwaway database before running these, since they create and delete
real rows.

```bash
cd backend
npm install
npm test
```
