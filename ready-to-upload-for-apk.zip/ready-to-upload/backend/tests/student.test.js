// Requires the generated server.js as-is (it already exports `app`
// and only calls .listen() when run directly — see server.js).
const request = require('supertest');
const app = require('../server');

describe('Student API', () => {
  let createdId;

  it('rejects creation with missing required fields', async () => {
    const res = await request(app).post('/api/students').send({});
    expect(res.status).toBe(400);
  });

  it('creates a Student', async () => {
    const res = await request(app).post('/api/students').send({ name: 'Test Value', grade: 42 });
    expect(res.status).toBe(201);
    expect(res.body.id).toBeDefined();
    createdId = res.body.id;
  });

  it('lists Students including the one just created', async () => {
    const res = await request(app).get('/api/students');
    expect(res.status).toBe(200);
    expect(res.body.some((item) => item.id === createdId)).toBe(true);
  });

  it('gets a single Student by id', async () => {
    const res = await request(app).get(`/api/students/${createdId}`);
    expect(res.status).toBe(200);
    expect(res.body.id).toBe(createdId);
  });

  it('returns 404 for a nonexistent Student', async () => {
    const res = await request(app).get('/api/students/999999999');
    expect(res.status).toBe(404);
  });

  it('deletes the Student', async () => {
    const res = await request(app).delete(`/api/students/${createdId}`);
    expect(res.status).toBe(204);
  });
});
