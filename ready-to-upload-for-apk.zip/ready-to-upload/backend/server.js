require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { PrismaClient } = require('@prisma/client');

const app = express();
const prisma = new PrismaClient();
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ONLINE' }));

// Minimal auth — generated because your spec requested authentication.
// This is NOT the full auth system from the main app-making-book
// backend (no 2FA, no sessions, no rate limiting) — it's the smallest
// real, working version: register + login + password hashing + JWT.
// Upgrade to the full pattern in backend/src/routes/authRoutes.ts of
// the main project if you need those features.
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

app.post('/api/auth/register', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password || password.length < 8) {
    return res.status(400).json({ error: 'email and password (min 8 chars) are required' });
  }
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(409).json({ error: 'Email already registered' });
  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({ data: { email, passwordHash } });
  res.status(201).json({ id: user.id, email: user.email });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

app.use('/api/students', require('./routes/studentRoutes')(prisma));
app.use('/api/exams', require('./routes/examRoutes')(prisma));

const PORT = process.env.PORT || 3000;
// Exporting `app` (and only listening when run directly, not when
// required by a test) is what lets backend/tests/*.test.js import this
// file and hit it with supertest without needing a real running server
// on a real port.
if (require.main === module) {
  app.listen(PORT, () => console.log('Listening on port ' + PORT));
}
module.exports = app;
