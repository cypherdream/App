import { defineConfig } from 'vitest/config';
// globals: true is what makes describe/it/expect available without an
// explicit import in every generated test file — without this, the
// generated tests in backend/tests/ fail with "describe is not defined".
export default defineConfig({ test: { globals: true } });
