const { Router } = require('express');
const { z } = require('zod');
const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing Authorization header' });
  try {
    jwt.verify(header.slice(7), process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

const studentSchema = z.object({
  name: z.string(),
  grade: z.number(),
  enrolled: z.boolean().optional(),
});

module.exports = function(prisma) {
  const router = Router();

  router.get('/', requireAuth, async (_req, res) => {
    const items = await prisma.student.findMany({ orderBy: { id: 'desc' } });
    res.json(items);
  });

  router.get('/:id', requireAuth, async (req, res) => {
    const item = await prisma.student.findUnique({ where: { id: Number(req.params.id) } });
    if (!item) return res.status(404).json({ error: 'Student not found' });
    res.json(item);
  });

  router.post('/', requireAuth, async (req, res) => {
    const parsed = studentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
    const item = await prisma.student.create({ data: parsed.data });
    res.status(201).json(item);
  });

  router.put('/:id', requireAuth, async (req, res) => {
    const parsed = studentSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
    const item = await prisma.student.update({ where: { id: Number(req.params.id) }, data: parsed.data });
    res.json(item);
  });

  router.delete('/:id', requireAuth, async (req, res) => {
    await prisma.student.delete({ where: { id: Number(req.params.id) } });
    res.status(204).send();
  });

  return router;
};
