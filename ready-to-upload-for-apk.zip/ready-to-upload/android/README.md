# School Manager — Android

Generated Kotlin source (data classes, Retrofit services, ViewModels per
entity) plus a real Gradle project structure. This does NOT compile itself —
no Android SDK exists in the environment that generated it. Two ways to get
a real APK:

1. Open `android/` in Android Studio and build normally.
2. Push to a GitHub repo and use `.github/workflows/build-android.yml`
   (included in this export) — builds on GitHub's free hosted runners,
   no local Android SDK needed. See that file for setup.
