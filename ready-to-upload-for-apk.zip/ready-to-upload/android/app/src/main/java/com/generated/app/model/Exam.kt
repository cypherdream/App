package com.generated.app.model

data class Exam(
    val id: Int = 0,
    val subject: String = "",
    val date: String = ""
)
