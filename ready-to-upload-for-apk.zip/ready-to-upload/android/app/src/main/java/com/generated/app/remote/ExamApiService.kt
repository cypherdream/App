package com.generated.app.remote

import com.generated.app.model.Exam
import retrofit2.http.*

interface ExamApiService {
    @GET("/api/exams")
    suspend fun getAll(): List<Exam>

    @GET("/api/exams/{id}")
    suspend fun getById(@Path("id") id: Int): Exam

    @POST("/api/exams")
    suspend fun create(@Body item: Exam): Exam

    @PUT("/api/exams/{id}")
    suspend fun update(@Path("id") id: Int, @Body item: Exam): Exam

    @DELETE("/api/exams/{id}")
    suspend fun delete(@Path("id") id: Int)
}
