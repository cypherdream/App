package com.generated.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.generated.app.model.Exam
import com.generated.app.remote.ExamApiService

/**
 * Generated ViewModel — follows the same MVVM pattern as the hand-written
 * reference app (android-app/src/.../MainViewModel.kt): a StateFlow the
 * Activity observes, no direct network calls from the UI layer.
 */
class ExamViewModel(private val api: ExamApiService) : ViewModel() {
    private val _items = MutableStateFlow<List<Exam>>(emptyList())
    val items: StateFlow<List<Exam>> = _items

    fun load() {
        viewModelScope.launch {
            _items.value = api.getAll()
        }
    }

    fun delete(id: Int) {
        viewModelScope.launch {
            api.delete(id)
            load()
        }
    }
}
