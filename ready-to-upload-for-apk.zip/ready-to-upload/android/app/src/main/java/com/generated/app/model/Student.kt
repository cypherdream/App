package com.generated.app.model

data class Student(
    val id: Int = 0,
    val name: String = "",
    val grade: Double = 0.0,
    val enrolled: Boolean? = null
)
