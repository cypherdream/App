package com.generated.app.remote

import com.generated.app.model.Student
import retrofit2.http.*

interface StudentApiService {
    @GET("/api/students")
    suspend fun getAll(): List<Student>

    @GET("/api/students/{id}")
    suspend fun getById(@Path("id") id: Int): Student

    @POST("/api/students")
    suspend fun create(@Body item: Student): Student

    @PUT("/api/students/{id}")
    suspend fun update(@Path("id") id: Int, @Body item: Student): Student

    @DELETE("/api/students/{id}")
    suspend fun delete(@Path("id") id: Int)
}
